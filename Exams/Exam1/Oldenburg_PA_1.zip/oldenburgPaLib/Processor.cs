﻿
using System.Linq;

namespace oldenburgPaLib
{
    public class Processor
    {
        public static List<Order> CheckType(string[] data)
        {
            string[] lines = data.Skip(2).ToArray();
            List<Order> orders = new List<Order>();
            Order? order = null;
            Detail? detail = null;
            foreach (string line in lines)
            {
                if (line.StartsWith("ORDER"))
                {
                    if (order != null)
                    {
                        orders.Append(order);
                    }

                    order = new Order(line.Split("\t"));
                }
                if (line.StartsWith("DETAIL"))
                {
                    detail = new Detail(line.Split("\t"));
                    order.addDetail(detail);
                }
            }
            return orders;
        }
    }
}