﻿

namespace oldenburgPaLib
{
    public class Order
    {
        public int? id;
        public string? customer;
        public string? country;
        public List<Detail>? details;
        public Order(string[] line)
        {
            id = int.Parse(line[1]);
            customer = line[2];
            country = line[3];
        }
        public void addDetail(Detail detail)
        {
            if (details != null)
            {
                details.Add(detail);
            }
        }
        public int getId()
        {
            return this.getId();
        }
    }
}