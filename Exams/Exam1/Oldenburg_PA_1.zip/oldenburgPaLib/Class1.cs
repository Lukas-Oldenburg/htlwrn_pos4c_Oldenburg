﻿
namespace oldenburgPaLib
{

public record Revenue(int Id, int sum);

    public class Class1
    {
        /// <summary>
        /// summarizes all total prices of all products per order id
        /// </summary>
        /// <param name="lines"></param>
        /// <returns></returns>
        public static string[] GetTotalPerOrder(List<Order> lines)
        {
            return lines
                .Select(line => line.id)
                .GroupBy(order => order.Value)
                .Select(groupedById => $"{groupedById.Key},{groupedById.Count()}")
                .ToArray();
        }
    }
}