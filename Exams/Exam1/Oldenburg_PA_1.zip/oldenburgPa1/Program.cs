﻿using oldenburgPaLib;
using System.Runtime.CompilerServices;

namespace oldenburgPaApp
{
    public partial class Program
    {
        static void Main(string[] args)
        {
            Processor proc = new Processor();
            var filename = args[0];


            var header = File.ReadAllLines(filename).Take(2);
            var data = File.ReadAllLines(filename);

            var orders = Processor.CheckType(data);

            var summarizedRevenue = Class1.GetTotalPerOrder(orders);
            foreach (var order in summarizedRevenue) 
            {
                Console.WriteLine(order.ToString());
            }

        }
    }
}